# High Performance Machine Learning
## Lab 4

## Commands to run the code
```
mpirun -n <world_size> python lab4_rpm390.py --data /scratch/gd66/spring2019/lab2/kaggleamazon/ --n-step <num_steps>
```

`launch_multinode.s` is the `sbatch` file to be submitted to run on prince cluster. To change the number of nodes, change the variable `num_worker` and to change number of steps change the variable `n_step`. 

### C2)

Number of workers: 4
```
Rank: 3 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 842.2869687764905
Rank: 4 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 825.0433708932251
Rank: 2 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 893.8333041104488
Rank: 1 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 908.7459048153833
```

Number of workers: 8
```
Rank: 8 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 411.7415429719258
Rank: 3 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 387.0473087467253
Rank: 2 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 389.32280091848224
Rank: 6 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 423.14353036601096
Rank: 4 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 424.3462622826919
Rank: 1 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 442.9402936268598
Rank: 7 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 429.23343218676746
Rank: 5 loss: 0.246770 prec@1: 0.925833 prec@3: 0.644356 total_exec_time: 427.9056065250188
```

Number of workers: 16
```
Rank: 12 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 176.5134377144277
Rank: 14 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 178.69718854688108
Rank: 11 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 182.93564755376428
Rank: 8 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 188.52774231974036
Rank: 2 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 185.33757238602266
Rank: 5 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 182.07115596625954
Rank: 16 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 184.2568042455241
Rank: 7 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 179.55285422224551
Rank: 10 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 176.7358967717737
Rank: 9 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 187.6765304962173
Rank: 1 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 187.7999968798831
Rank: 6 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 196.36208512820303
Rank: 3 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 215.92085863184184
Rank: 4 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 217.82150413654745
Rank: 13 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 213.59580234903842
Rank: 15 loss: 0.261580 prec@1: 0.925531 prec@3: 0.643865 total_exec_time: 217.52059097215533
```

This is just the output after last step. The full output is provided in the log files attached with the submission. 
The format of the log file is: `lab4_<num_worker>-<n_step>.out`

### C3)

n_step: 2
```
Rank: 3 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 842.2869687764905
Rank: 4 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 825.0433708932251
Rank: 2 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 893.8333041104488
Rank: 1 loss: 0.230135 prec@1: 0.928333 prec@3: 0.652467 total_exec_time: 908.7459048153833
```

n_step: 5
```
Rank: 3 loss: 0.220164 prec@1: 0.940467 prec@3: 0.655600 total_exec_time: 837.7076123692095
Rank: 1 loss: 0.220164 prec@1: 0.940467 prec@3: 0.655600 total_exec_time: 749.7802905580029
Rank: 4 loss: 0.220164 prec@1: 0.940467 prec@3: 0.655600 total_exec_time: 866.9797081053257
Rank: 2 loss: 0.220164 prec@1: 0.940467 prec@3: 0.655600 total_exec_time: 837.4925359468907
```

n_step: 10
```
Rank: 3 loss: 0.229397 prec@1: 0.936533 prec@3: 0.650889 total_exec_time: 865.9130924267229
Rank: 2 loss: 0.229397 prec@1: 0.936533 prec@3: 0.650889 total_exec_time: 981.9879773557186
Rank: 1 loss: 0.229397 prec@1: 0.936533 prec@3: 0.650889 total_exec_time: 753.0949604092166
Rank: 4 loss: 0.229397 prec@1: 0.936533 prec@3: 0.650889 total_exec_time: 890.0005455710925
```

n_step: 20
```
Rank: 2 loss: 0.241939 prec@1: 0.924400 prec@3: 0.644611 total_exec_time: 853.1815560362302
Rank: 3 loss: 0.241939 prec@1: 0.924400 prec@3: 0.644611 total_exec_time: 816.5774858118966
Rank: 1 loss: 0.241939 prec@1: 0.924400 prec@3: 0.644611 total_exec_time: 726.4919792087749
Rank: 4 loss: 0.241939 prec@1: 0.924400 prec@3: 0.644611 total_exec_time: 830.1725547127426
```

This is just the output after last step. The full output is provided in the log files attached with the submission. 
The format of the log file is: `lab4_<num_worker>-<n_step>.out`
