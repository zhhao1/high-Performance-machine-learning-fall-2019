#import pandas as pd
import os
from PIL import Image
import time
import csv
import random
import pandas as pd
#from torch import np
import numpy as np

import torch
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
from torch import nn
import torch.optim as optim
import torch.nn.functional as F
import argparse


class KaggleAmazonDataset(Dataset):

    def __init__(self, csv_path, img_path, img_ext, transform=None):

        tmp_df = pd.read_csv(csv_path)

        self.img_path = img_path
        self.img_ext = img_ext
        self.transform = transform

        self.X_train = tmp_df['image_name']
        self.y_train = tmp_df['tags']

        self.num_labels = 17

    def __getitem__(self, index):
        img = Image.open(self.img_path + self.X_train[index] + self.img_ext)
        img = img.convert('RGB')
        if self.transform is not None:
            img = self.transform(img)
        label_ids = self.y_train[index].split()
        label_ids = [int(s) for s in label_ids]
        label = torch.zeros(self.num_labels)
        label[label_ids] = 1
        return img, label

    def __len__(self):
        return len(self.X_train.index)


class Inception_Module(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(Inception_Module, self).__init__()
        self.conv1x1 = nn.Conv2d(
            in_channels, out_channels, kernel_size=1, stride=1, padding=0)
        self.conv3x3 = nn.Conv2d(
            in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.conv5x5 = nn.Conv2d(
            in_channels, out_channels, kernel_size=5, stride=1, padding=2)

    def forward(self, x):
        conv1x1 = self.conv1x1(x)
        conv3x3 = self.conv3x3(x)
        conv5x5 = self.conv5x5(x)
        out = [conv1x1, conv3x3, conv5x5]
        out = torch.cat(out, 1)
        return out


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.module1 = Inception_Module(3, 10)
        self.module2 = Inception_Module(30, 10)
        self.fc1 = nn.Linear(1920, 256)
        self.fc2 = nn.Linear(256, 17)

    def forward(self, x):
        x = self.module1(x)
        x = F.relu(F.max_pool2d(x, 2))
        x = self.module2(x)
        x = F.relu(F.max_pool2d(x, 2))
        x = x.view(x.size(0), -1)  # Flatten layer
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return torch.sigmoid(x)


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def train(epoch, train_loader, model, criterion, optimizer):
    loader_times = AverageMeter()
    batch_times = AverageMeter()
    losses = AverageMeter()
    precisions_1 = AverageMeter()
    precisions_k = AverageMeter()

    model.train()

    t_train = time.monotonic()
    t_batch = time.monotonic()
    for batch_idx, (data, target) in enumerate(train_loader):
        loader_time = time.monotonic() - t_batch
        loader_times.update(loader_time)
        data = data.to(device=device)
        target = target.to(device=device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()

        optimizer.step()
        batch_times.update(time.monotonic() - t_batch)

        topk = 3
        _, predicted = output.topk(topk, 1, True, True)
        batch_size = target.size(0)
        prec_k = 0
        prec_1 = 0
        count_k = 0
        for i in range(batch_size):
            prec_k += target[i][predicted[i]].sum()
            prec_1 += target[i][predicted[i][0]]
            count_k += topk  # min(target[i].sum(), topk)
        prec_k /= count_k
        prec_1 /= batch_size
        #print ('prec_1',prec_1)

        # Update of averaged metrics
        losses.update(loss.item(), 1)
        precisions_1.update(prec_1, 1)
        precisions_k.update(prec_k, 1)

        if (batch_idx+1) % 500 == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.3f} ({:.3f}),\tPrec@1: {:.3f} ({:.3f}),\tPrec@3: {:.3f} ({:.3f}),\tTimes: Batch: {:.4f} ({:.4f}),\tDataLoader: {:.4f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx /
                len(train_loader), losses.val, losses.avg, precisions_1.val, precisions_1.avg, precisions_k.val, precisions_k.avg,
                batch_times.val, batch_times.avg, loader_times.avg))

        t_batch = time.monotonic()

    train_time = time.monotonic() - t_train
    print('Training Epoch: {} done. \tLoss: {:.3f},\tPrec@1: {:.3f},\tPrec@3: {:.3f}\tTimes: Total: {:.3f}, Avg-Batch: {:.4f}, Avg-Loader: {:.4f}\n'.format(epoch,
                                                                                                                                                            losses.avg, precisions_1.avg, precisions_k.avg, train_time, batch_times.avg, loader_times.avg))
    return train_time, batch_times.avg, loader_times.avg


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PyTorch Example')
    parser.add_argument('--disable_cuda', action='store_true',
                        help='Disable CUDA')
    parser.add_argument('--workers', type=int, default=4,
                        help='Number of dataloader workers')
    parser.add_argument('--data_path', type=str, default='data/',
                        help='Data path')
    parser.add_argument('--opt', type=str, default='sgd',
                        help='NN optimizer (Examples: adam, rmsprop, adadelta, ...)')
    args = parser.parse_args()
    device = None
    if not args.disable_cuda and torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')

    print('device:', device)
    DATA_PATH = args.data_path
    # DATA_PATH='data/'
    IMG_PATH = DATA_PATH+'train-jpg/'
    IMG_EXT = '.jpg'
    TRAIN_DATA = DATA_PATH+'train20k.csv'
    print('dataloader_workers', args.workers)
    batch_size = 250

    transformations = transforms.Compose(
        [transforms.Resize(32), transforms.ToTensor()])

    dset_train = KaggleAmazonDataset(
        TRAIN_DATA, IMG_PATH, IMG_EXT, transformations)

    train_loader = DataLoader(dset_train,
                              batch_size=batch_size,
                              shuffle=True,
                              num_workers=args.workers  # 1 for CUDA
                              )

    print('dataset loaded')

    model = Net().to(device=device)

    print('Optimizer:', args.opt)
    if args.opt == 'adam':
        optimizer = optim.Adam(model.parameters(), lr=0.01)
    elif args.opt == 'adagrad':
        optimizer = optim.Adagrad(model.parameters(), lr=0.01)
    elif args.opt == 'adadelta':
        optimizer = optim.Adadelta(model.parameters(), lr=1.0)
    elif args.opt == 'nesterov':
        optimizer = optim.SGD(model.parameters(), lr=0.01,
                              momentum=0.9, nesterov=True)
    else:
        optimizer = optim.SGD(model.parameters(), lr=0.01,
                              momentum=0.9, nesterov=False)

    criterion = nn.BCELoss().to(device=device)

    train_times = []
    batch_times = []
    loader_times = []
    for epoch in range(5):
        train_time, batch_time, loader_time = train(
            epoch, train_loader, model, criterion, optimizer)
        train_times.append(train_time)
        batch_times.append(batch_time)
        loader_times.append(loader_time)

    print('Final Average Times: Total: {:.3f}, Avg-Batch: {:.4f}, Avg-Loader: {:.4f}\n'.format(
        np.average(train_times), np.average(batch_times), np.average(loader_times)))
